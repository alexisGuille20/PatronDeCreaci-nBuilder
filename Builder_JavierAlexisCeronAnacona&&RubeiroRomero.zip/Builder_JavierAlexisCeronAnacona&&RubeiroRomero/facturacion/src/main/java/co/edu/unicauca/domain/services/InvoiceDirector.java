/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unicauca.domain.services;

import co.edu.unicauca.domain.entities.Invoice;
import co.edu.unicauca.domain.entities.ShoppingCart;
import co.edu.unicauca.domain.entities.ShoppingCartItem;

/**
 *
 * @author ANACONA
 */
public class InvoiceDirector {
    private InvoiceBuilder builder;

    public InvoiceDirector(InvoiceBuilder builder) {
        this.builder = builder;
    }

    public Invoice createInvoice(String clientName, ShoppingCart cart) {
        builder.createNewInvoice(clientName); // Se pasa el nombre del cliente
        for (ShoppingCartItem item : cart.getItems()) {
            builder.addInvoiceItem(item);
        }
        return builder.getInvoice();
    }
}
