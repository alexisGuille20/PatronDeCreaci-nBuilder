package co.edu.unicauca.domain.services;

import co.edu.unicauca.domain.entities.Invoice;
import co.edu.unicauca.domain.entities.ShoppingCartItem;

/**
 *
 * @author ANACONA
 */
public abstract class InvoiceBuilder {
    protected Invoice invoice;

    // Método para crear una nueva factura con el nombre del cliente
    public void createNewInvoice(String clientName) {
        invoice = new Invoice(clientName);
    }

    public abstract void addInvoiceItem(ShoppingCartItem item);

    public Invoice getInvoice() {
        return invoice;
    }
}
