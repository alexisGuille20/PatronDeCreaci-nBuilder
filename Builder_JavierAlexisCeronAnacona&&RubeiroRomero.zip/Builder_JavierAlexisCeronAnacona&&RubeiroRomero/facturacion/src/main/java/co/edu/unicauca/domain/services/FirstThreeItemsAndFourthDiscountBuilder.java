/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unicauca.domain.services;

import co.edu.unicauca.domain.entities.InvoiceItem;
import co.edu.unicauca.domain.entities.ShoppingCartItem;

/**
 *
 * @author ANACONA
 */
public class FirstThreeItemsAndFourthDiscountBuilder extends InvoiceBuilder{
    private int itemCount;

    @Override
    public void addInvoiceItem(ShoppingCartItem item) {
        
        itemCount++;
        double discount = (itemCount <= 3) ? 10.0 : (itemCount == 4 ? 5.0 : 0.0);
        invoice.addInvoiceItem(new InvoiceItem(item.getName(), item.getPrice(), discount));
    }
}
