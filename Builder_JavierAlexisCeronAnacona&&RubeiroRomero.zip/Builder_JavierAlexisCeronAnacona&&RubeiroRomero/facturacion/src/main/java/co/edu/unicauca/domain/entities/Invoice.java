package co.edu.unicauca.domain.entities;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ANACONA
 */
public class Invoice {
    private String clientName;
    private List<InvoiceItem> items = new ArrayList<>();
    private double totalPrice;
    private int discountCount; // Contador de ítems con descuento

    public Invoice(String clientName) {
        this.clientName = clientName;
        this.totalPrice = 0;
        this.discountCount =0;
    }

    public void addInvoiceItem(InvoiceItem item) {
        items.add(item);
        totalPrice += item.getFinalPrice();

        // Si el descuento es mayor a 0, incrementamos el contador
        if (item.getDiscount() > 0) {
            discountCount++;
        }
    }

    public void printInvoice() {
        System.out.println("Factura para: " + clientName);
        for (InvoiceItem item : items) {
            System.out.println(item);
        }
        System.out.println("Total: " + totalPrice);
        System.out.println("Cantidad de descuentos aplicados: " + discountCount); // Mostramos el total de descuentos
    }
}
