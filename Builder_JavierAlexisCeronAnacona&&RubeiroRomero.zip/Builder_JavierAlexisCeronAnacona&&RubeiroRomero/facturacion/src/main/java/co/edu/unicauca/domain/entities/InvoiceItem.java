/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unicauca.domain.entities;

/**
 *
 * @author ANACONA
 */
public class InvoiceItem {
    private String name;
    private double price;
    private double discount;

    public InvoiceItem(String name, double price, double discount) {
        this.name = name;
        this.price = price;
        this.discount = discount;
    }

    public double getFinalPrice() {
        return price - (price * discount / 100);
    }

    public double getDiscount() { // Método para obtener el descuento
        return discount;
    }

    @Override
    public String toString() {
        return name + " - Precio: " + price + " - Descuento: " + discount + "% - Precio final: " + getFinalPrice();
    }
}
