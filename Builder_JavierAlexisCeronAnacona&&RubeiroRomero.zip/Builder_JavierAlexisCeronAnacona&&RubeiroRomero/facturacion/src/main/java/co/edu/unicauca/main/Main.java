/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unicauca.main;

import co.edu.unicauca.domain.entities.Invoice;
import co.edu.unicauca.domain.entities.ShoppingCart;
import co.edu.unicauca.domain.entities.ShoppingCartItem;
import co.edu.unicauca.domain.services.FirstThreeItemsAndFourthDiscountBuilder;
import co.edu.unicauca.domain.services.InvoiceBuilder;
import co.edu.unicauca.domain.services.InvoiceDirector;
import co.edu.unicauca.domain.services.SecondItemDiscountBuilder;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author ANACONA
 */
public class Main {
        public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            boolean continuar = true;
            
            while (continuar) {
                System.out.println("==================================");
                System.out.println("      SISTEMA DE FACTURACION      ");
                System.out.println("==================================");

                // Pedimos el nombre del cliente
                System.out.print("Ingrese el nombre del cliente: ");
                String clientName = scanner.nextLine().trim();

                // Creamos el carrito de compras
                ShoppingCart cart = new ShoppingCart();
                cart.addItem(new ShoppingCartItem("Bufanda de seda", 100000));
                cart.addItem(new ShoppingCartItem("Bufanda de seda", 100000));
                cart.addItem(new ShoppingCartItem("Vestido de seda", 2900000));
                cart.addItem(new ShoppingCartItem("Bufanda de seda", 100000));

                int choice = 0;
                while (choice != 1 && choice != 2) {
                    try {
                        System.out.println("\nSeleccione una politica de descuento:");
                        System.out.println("1. Segundo item con 10% de descuento");
                        System.out.println("2. Primeros tres con 10% y cuarto con 5%");
                        System.out.print("Opcion: ");
                        choice = scanner.nextInt();
                        scanner.nextLine();

                        if (choice != 1 && choice != 2) {
                            System.out.println("❌ Opción invalida. Intente nuevamente.");
                        }
                    } catch (InputMismatchException e) {
                        System.out.println("❌ Entrada no valida. Debe ingresar un número.");
                        scanner.nextLine();
                    }
                }

                // Asignamos la política de descuento
                InvoiceBuilder builder = (choice == 1)
                        ? new SecondItemDiscountBuilder()
                        : new FirstThreeItemsAndFourthDiscountBuilder();

                // Creamos la factura con la política seleccionada
                InvoiceDirector director = new InvoiceDirector(builder);
                Invoice invoice = director.createInvoice(clientName, cart);

                // Mostramos la factura
                invoice.printInvoice();

                // Preguntar si quiere generar otra factura
                System.out.print("\n¿Desea generar otra factura? (S/N): ");
                String respuesta = scanner.nextLine().trim().toUpperCase();
                continuar = respuesta.equals("S");
            }

            System.out.println("✅ Gracias por usar el sistema de facturacion. ¡Hasta pronto!");
        } catch (Exception e) {
            System.out.println("❌ Ocurrio un error inesperado: " + e.getMessage());
        }
    }
}
