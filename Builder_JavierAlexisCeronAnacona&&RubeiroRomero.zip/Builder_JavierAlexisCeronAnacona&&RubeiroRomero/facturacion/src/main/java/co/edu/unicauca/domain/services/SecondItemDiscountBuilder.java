/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unicauca.domain.services;

import co.edu.unicauca.domain.entities.InvoiceItem;
import co.edu.unicauca.domain.entities.ShoppingCartItem;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author ANACONA
 */
public class SecondItemDiscountBuilder extends InvoiceBuilder{
    private Map<String, Integer> itemCount = new HashMap<>();

    
    @Override
    public void addInvoiceItem(ShoppingCartItem item) {
        int count = itemCount.getOrDefault(item.getName(), 0) + 1;
        itemCount.put(item.getName(), count);

        double discount = (count == 2) ? 10.0 : 0.0;
        invoice.addInvoiceItem(new InvoiceItem(item.getName(), item.getPrice(), discount));
    }
}
